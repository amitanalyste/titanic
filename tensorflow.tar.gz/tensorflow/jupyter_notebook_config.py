c = get_config()
c.IPKernelApp.matplotlib = 'inline'
c.NotebookApp.open_browser = False
c.NotebookApp.ip = '*'
c.NotebookApp.port = 8888

